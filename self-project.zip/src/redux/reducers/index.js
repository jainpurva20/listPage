import { combineReducers } from 'redux';
import getListData from "./reducerGetListData"; 

export default combineReducers({
    getListData
})

