import React, { Component } from 'react';

class TimeLineComponent extends Component {
    constructor(props) {
        super(props)
    }
    onEventCLick = () => {
        alert(this.props.createdAt)
    }
    render() {
        return (<div className="p-2" onClick={this.onEventCLick}>
            <div>{this.props.createdAt}</div>
            <div>{this.props.title}</div>
            <div className="p-1  bg-white">
                {this.props.children}
            </div>
        </div>)
    }
}

export default TimeLineComponent;